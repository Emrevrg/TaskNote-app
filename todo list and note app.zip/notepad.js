document.addEventListener('DOMContentLoaded', function() {
    const area = document.getElementById('notepad-area');
    const saveBtn = document.getElementById('save-note');
    const clearBtn = document.getElementById('clear-note');
    const status = document.getElementById('save-status');

    // Load note from localStorage
    area.value = localStorage.getItem('notepad-gold') || '';

    function showStatus(msg, timeout = 1200) {
        status.textContent = msg;
        status.style.opacity = 1;
        if (timeout) {
            setTimeout(() => {
                status.style.opacity = 0;
            }, timeout);
        }
    }

    saveBtn.addEventListener('click', function() {
        localStorage.setItem('notepad-gold', area.value);
        showStatus('Kaydedildi!');
    });

    clearBtn.addEventListener('click', function() {
        area.value = '';
        localStorage.removeItem('notepad-gold');
        showStatus('Temizlendi!');
    });

    area.addEventListener('input', function() {
        showStatus('');
    });
});
