document.addEventListener('DOMContentLoaded', function() {
    const input = document.getElementById('todo-input');
    const timeInput = document.getElementById('todo-time');
    const addBtn = document.getElementById('add-btn');
    const list = document.getElementById('todo-list');
    const filterBtns = document.querySelectorAll('.filter-btn');
    const taskCount = document.getElementById('task-count');
    const clearCompletedBtn = document.getElementById('clear-completed');

    let todos = JSON.parse(localStorage.getItem('todos-gold')) || [];
    let filter = 'all';

    function saveTodos() {
        localStorage.setItem('todos-gold', JSON.stringify(todos));
    }

    function renderTodos() {
        list.innerHTML = '';
        let filtered = todos.filter(todo => {
            if (filter === 'all') return true;
            if (filter === 'active') return !todo.completed;
            if (filter === 'completed') return todo.completed;
        });
        filtered.forEach((todo, idx) => {
            const li = document.createElement('li');
            li.style.animationDelay = (idx * 0.04) + 's';
            const span = document.createElement('span');
            span.className = 'todo-text' + (todo.completed ? ' completed' : '');
            span.textContent = todo.text;
            span.onclick = function() {
                todo.completed = !todo.completed;
                saveTodos();
                renderTodos();
            };
            if (todo.time) {
                const timeTag = document.createElement('span');
                timeTag.className = 'todo-time-tag';
                timeTag.textContent = todo.time;
                li.appendChild(timeTag);
            }
            const delBtn = document.createElement('button');
            delBtn.textContent = 'Sil';
            delBtn.className = 'delete-btn';
            delBtn.onclick = function() {
                li.style.transform = 'scale(0.7) translateX(60px)';
                li.style.opacity = '0';
                setTimeout(() => {
                    todos = todos.filter(t => t !== todo);
                    saveTodos();
                    renderTodos();
                }, 300);
            };
            li.appendChild(span);
            li.appendChild(delBtn);
            list.appendChild(li);
        });
        updateCount();
    }

    function addTodo() {
        const text = input.value.trim();
        const time = timeInput.value;
        if (text === '') return;
        todos.unshift({ text, time: time || null, completed: false });
        saveTodos();
        renderTodos();
        input.value = '';
        timeInput.value = '';
        input.focus();
    }

    function updateCount() {
        const active = todos.filter(t => !t.completed).length;
        const total = todos.length;
        taskCount.textContent = `${total} görev (${active} aktif)`;
    }

    addBtn.addEventListener('click', addTodo);
    input.addEventListener('keydown', function(e) {
        if (e.key === 'Enter') addTodo();
    });
    timeInput.addEventListener('keydown', function(e) {
        if (e.key === 'Enter') addTodo();
    });

    filterBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            filterBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            filter = btn.getAttribute('data-filter');
            renderTodos();
        });
    });

    clearCompletedBtn.addEventListener('click', function() {
        todos = todos.filter(t => !t.completed);
        saveTodos();
        renderTodos();
    });

    renderTodos();
});
