// Gelişmiş Not Defteri: Çoklu not, başlık, düzenleme, otomatik kaydetme

document.addEventListener('DOMContentLoaded', function() {
    const notesListSection = document.querySelector('.notes-list-section');
    const notesList = document.getElementById('notes-list');
    const newNoteBtn = document.getElementById('new-note-btn');
    const noteEditorSection = document.querySelector('.note-editor-section');
    const noteTitleInput = document.getElementById('note-title');
    const noteArea = document.getElementById('notepad-area');
    const saveBtn = document.getElementById('save-note');
    const deleteBtn = document.getElementById('delete-note');
    const backBtn = document.getElementById('back-notes');
    const status = document.getElementById('save-status');

    let notes = JSON.parse(localStorage.getItem('notepad-advanced')) || [];
    let selectedId = null;
    let autoSaveTimeout = null;

    function showList() {
        noteEditorSection.style.display = 'none';
        notesListSection.style.display = 'block';
        renderNotesList();
    }

    function showEditor(id) {
        notesListSection.style.display = 'none';
        noteEditorSection.style.display = 'flex';
        if (id !== null) {
            const note = notes.find(n => n.id === id);
            noteTitleInput.value = note.title || '';
            noteArea.value = note.content || '';
            selectedId = id;
            deleteBtn.style.display = '';
        } else {
            noteTitleInput.value = '';
            noteArea.value = '';
            selectedId = null;
            deleteBtn.style.display = 'none';
        }
        status.textContent = '';
    }

    function renderNotesList() {
        notesList.innerHTML = '';
        if (notes.length === 0) {
            const li = document.createElement('li');
            li.textContent = 'Henüz not yok.';
            li.style.opacity = '0.7';
            notesList.appendChild(li);
            return;
        }
        notes.slice().reverse().forEach(note => {
            const li = document.createElement('li');
            li.textContent = note.title ? note.title : (note.content ? note.content.slice(0, 30) + (note.content.length > 30 ? '...' : '') : 'Başlıksız Not');
            if (note.id === selectedId) li.classList.add('selected');
            li.onclick = () => showEditor(note.id);
            notesList.appendChild(li);
        });
    }

    function saveNotesToStorage() {
        localStorage.setItem('notepad-advanced', JSON.stringify(notes));
    }

    function saveCurrentNote(showMsg = true) {
        const title = noteTitleInput.value.trim();
        const content = noteArea.value;
        if (selectedId === null) {
            // Yeni not
            if (!title && !content) return;
            const id = Date.now();
            notes.push({ id, title, content, date: new Date().toISOString() });
            selectedId = id;
        } else {
            // Var olan notu güncelle
            const note = notes.find(n => n.id === selectedId);
            if (note) {
                note.title = title;
                note.content = content;
                note.date = new Date().toISOString();
            }
        }
        saveNotesToStorage();
        if (showMsg) showStatus('Kaydedildi!');
        renderNotesList();
    }

    function showStatus(msg, timeout = 1200) {
        status.textContent = msg;
        status.style.opacity = 1;
        if (timeout) {
            setTimeout(() => {
                status.style.opacity = 0;
            }, timeout);
        }
    }

    newNoteBtn.onclick = function() {
        showEditor(null);
    };

    saveBtn.onclick = function() {
        saveCurrentNote();
    };

    deleteBtn.onclick = function() {
        if (selectedId !== null) {
            notes = notes.filter(n => n.id !== selectedId);
            saveNotesToStorage();
            showList();
        }
    };

    backBtn.onclick = function() {
        showList();
    };

    // Otomatik kaydetme
    noteTitleInput.addEventListener('input', autoSave);
    noteArea.addEventListener('input', autoSave);

    function autoSave() {
        if (autoSaveTimeout) clearTimeout(autoSaveTimeout);
        autoSaveTimeout = setTimeout(() => {
            saveCurrentNote(false);
        }, 600);
    }

    // İlk açılışta listeyi göster
    showList();
});
